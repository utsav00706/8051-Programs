/* FLASH.C - LED Flasher for the Keil MCB251 Evaluation Board with 80C51 device*/
                
#include <at89x51.H>
void main () 
{
	P2 = 0Xff;
	P1 = 0;
	while(1)
	{ 
  if (P2_0==0)
	{
		P1 =0x01;
		}		
else if (P2_1==0)
	{
		P1 =0x02;
		}		
	else if (P2_2==0)
		{
		P1 =0x04;
		}		
		else if (P2_3==0)
			{
		P1 =0x08;
		}		
	}
}

















