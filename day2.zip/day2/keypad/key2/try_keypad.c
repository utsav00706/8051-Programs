#include <REGX52.H>
sfr op = 0xA0;
sfr keyport = 0x90;
sbit one=P3^0;
void delay(int del);
char scanKeypad();
unsigned char disp(unsigned char);
void main()
{
char key;
one=1;
	while(1)
{
key = scanKeypad();	
op = disp(key);
}
}
void delay(int del)
{
int i,j;
for(i=1;i<=del;i++)
	for(j=1;j<=1275;j++);
}

char scanKeypad()
{
keyport=0xFE;
if(keyport==0xEE)
	return 0;
if(keyport==0xDE)
	return 1;
if(keyport==0xBE)
	return 2;
if(keyport==0x7E)
	return 3;
	
keyport=0xFD;
if(keyport==0xED)
	return 4;
if(keyport==0xDD)
	return 5;
if(keyport==0xBD)
	return 6;
if(keyport==0x7D)
	return 7;

keyport=0xFB;
if(keyport==0xEB)
	return 8;
if(keyport==0xDB)
	return 9;
if(keyport==0xBB)
	return 0x0a;
if(keyport==0x7B)
	return 0x0b;

keyport=0xF7;
if(keyport==0xE7)
	return 0x0c;
if(keyport==0xD7)
	return 0x0d;
if(keyport==0xB7)
	return 0x0e;
if(keyport==0x77)
	return 0x0f;

return '\0';
}
unsigned char disp(unsigned char x)
{
	unsigned char b=0;
	
	  switch(x)
     {	
			 case 0:
			   {
			   b=63;
					 break;
         }
        case 1:
			   {
			   b=6;
					 break;
         }
				case 2:
			   { 
			   b=91;
					 break;
         }
				case 3:
			   {
			   b=79;
					 break;
         }
				case 4:
			   {
			   b=102;
					 break;
         }
				case 5:
			   {
			   b=109;
					 break;
         }
				case 6:
			   {
			   b=125;
					 break;
         }
				case 7:
			   {
			   b=7;
					 break;
         }
				case 8:
			   {
			   b=127;
					 break;
         }
				case 9:
			   {
			   b=111;
					 break;
         }
				case 10:
			   {
			   b=119;
					 break;
         }
				case 11:
			   {
			   b=124;
					 break;
         }
				case 12:
			   {
			   b=57;
					 break;
         }
				case 13:
			   {
			   b=94;
					 break;
         }
				case 14:
			   {
			   b=121;
					 break;
         }
				default:
			   {
			   b=113;
					 break;
         }	
				 }
			 return b;
}

