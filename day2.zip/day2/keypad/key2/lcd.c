#include <REGX52.H>
#include "lcd.h"
//int LCDWriteNum(int x,int y, float fnum);
sfr lcdport=0xA0;
sbit rs=P3^0;
sbit en=P3^1;
sbit rw=P3^2;
void lcddelay(int del)
{
	int i,j;
	for(i=0;i<=del;i++)
		for(j=0;j<=1000;j++);
}
void LCDWriteString(int x,int y, unsigned char ldata[])
{
	int i=0;
	int count=0;
	if(x==1)
		lcdport=0xC0+y;
	else
		lcdport=0x80+y;
	
	rs=0;
	rw=0;	
	en=1;
	lcddelay(1);
	en=0;
	while(ldata[i]!='\0')
	{	
	lcdport=ldata[i];
	rs=1;
	en=1;
	lcddelay(1);
	en=0;
	i=i+1;	
	count=count+1;	
	}	
}
void LCDWriteInt(int x,int y, int lnum)
{
int num,count=0,arr[10],i;
	if(lnum<0)
	{
		lnum=lnum*-1;
		LCDWriteString(x,y, "-");
		y=y+1;
	}
	if(x==1)
		lcdport=0xC0+y;
	else
		lcdport=0x80+y;
	rs=0; 
	rw=0;
	en=1;
	lcddelay(1);
	en=0;
	num=(int)lnum;
	if(num==0)
	{
	lcdport=0x30;	
	rs=1;
	en=1;
	lcddelay(1);
	en=0;
	}
	while(num)
	{
	arr[count]=	num%0x0A;
	num=num/0x0A;
	count=count+1;	
	}
	for(i=count-1;i>=0;i--)
	{
	lcdport=0x30+arr[i];	
	rs=1;
	en=1;
	lcddelay(1);
	en=0;
	}
}

//char * LCDGetData()
//{
//char *msg;
//rs=1;
//rw=1;
//}

///Experimental Eating memory due to repetition and buggy try sprintf instead
//void LCDWriteNum(int x,int y, float lnum)
//{
//	int num,count=0,i,arr[10];
//	float f;
//	if(lnum<0)
//	{
//		lnum=lnum*-1;
//		LCDWriteString(x,y, "-");
//		y=y+1;
//	}
//	num=lnum;
//	f=lnum-num;
//	if(x==1)
//		lcdport=0xC0+y;
//	else
//		lcdport=0x80+y;
//	rs=0;
//	rw=0;
//	en=1;
//	lcddelay(1);
//	en=0;
//	num=(int)lnum;
//	while(num)
//	{
//	arr[count]=	num%0x0A;
//	num=num/0x0A;
//	count=count+1;	
//	}
//	for(i=count-1;i>=0;i--)
//	{
//	lcdport=0x30+arr[i];	
//	rs=1;
//	en=1;
//	lcddelay(1);
//	en=0;
//	}	
//if(f!=0)
//{
//num=f*1000;
//if(num!=0)
//{	
//y=y+count;	
//LCDWriteString(x,y, ".");	
//if (f<0.01)
//{
//y=y+1;
//LCDWriteString(x,y, "0");
//y=y+1;
//LCDWriteString(x,y, "0");		
//}
//else if (f<0.1)
//{
//y=y+1;
//LCDWriteString(x,y, "0");		
//}
//LCDWriteInt(x,y+1,num);	
//}	
//}
//}
void LCDInit()
{
	rs=0;
	rw=0;
	lcdport=0x38;
	en=1;
	lcddelay(1);
	en=0;
	lcdport=0x0E;
	en=1;
	lcddelay(1);
	en=0;
}
void LCDClear()
{
	rs=0;
	rw=0;
	lcdport=0x01;
	en=1;
	lcddelay(1);
	en=0;
}