#include <REGX52.H>
sfr op = 0xA0;
sfr keyport = 0x90;
unsigned char disp(unsigned char );
void main()
{

while(1)
{
keyport=0xFE;
if(keyport==0xEE)
op = disp(0);
if(keyport==0xDE)
op = disp(1);
if(keyport==0xBE)
op = disp(2);
if(keyport==0x7E)
op = disp(3);

keyport=0xFD;
if(keyport==0xED)
op = disp(4);
if(keyport==0xDD)
op = disp(5);
if(keyport==0xBD)
op = disp(6);
if(keyport==0x7D)
op = disp(7);

keyport=0xFB;
if(keyport==0xEB)
op = disp(8);
if(keyport==0xDB)
op = disp(9);
if(keyport==0xBB)
op = disp(10);
if(keyport==0x7B)
op = disp(11);

keyport=0xF7;
if(keyport==0xE7)
op = disp(12);
if(keyport==0xD7)
op = disp(13);
if(keyport==0xB7)
op = disp(14);
if(keyport==0x77)
op = disp(15);
}
}

unsigned char disp(unsigned char x)
{
	unsigned char b=0;
	
	  switch(x)
     {	
			 case 0:
			   {
			   b=63;
					 break;
         }
        case 1:
			   {
			   b=6;
					 break;
         }
				case 2:
			   { 
			   b=91;
					 break;
         }
				case 3:
			   {
			   b=79;
					 break;
         }
				case 4:
			   {
			   b=102;
					 break;
         }
				case 5:
			   {
			   b=109;
					 break;
         }
				case 6:
			   {
			   b=125;
					 break;
         }
				case 7:
			   {
			   b=7;
					 break;
         }
				case 8:
			   {
			   b=127;
					 break;
         }
				case 9:
			   {
			   b=111;
					 break;
         }
				case 10:
			   {
			   b=119;
					 break;
         }
				case 11:
			   {
			   b=124;
					 break;
         }
				case 12:
			   {
			   b=57;
					 break;
         }
				case 13:
			   {
			   b=94;
					 break;
         }
				case 14:
			   {
			   b=121;
					 break;
         }
				default:
			   {
			   b=113;
					 break;
         }	
				 }
			 return b;
}


