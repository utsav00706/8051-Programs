#include <REGX51.H>
void delay(unsigned int);

void main()
{
    P3=0x00;
		P0=0x07;
		delay(2000);
		
		P3=0x00;
		P0=0x00;
		delay(2000);
		
		

  while(1)
	{ 
		P3=0x7f;
		P0=0x01;
		delay(500);
		
		P3=0xbf;
		P0=0x02;
		delay(500);
		
		P3=0xdf;
		P0=0x04;
		delay(500);
    
		P3=0xef;
		P0=0x02;
		delay(500);
		
		P3=0xf7;
		P0=0x01;
		delay(500);
		
		P3=0xfb;
		P0=0x02;
		delay(500);
		
		P3=0xfd;
		P0=0x04;
		delay(500);
		
		P3=0xfe;
		P0=0x02;
		delay(500);
		
}
}

 void delay(unsigned int x)
{ unsigned int i,j;
    for (i=0;i<x;i++)
        for(j=0;j<175;j++)
	  {}
}	
		
		