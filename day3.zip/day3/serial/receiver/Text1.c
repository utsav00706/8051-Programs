#include <REG51.H>

//void delay (unsigned int);
unsigned char recieve(void);
void transmit(unsigned char x)        //   Serial TransmtSubroutine
{
	SBUF = x;					    //	 Put the data into transmit buffer
	while(TI==0);	                //   Wait until transmission of previous occurs
	TI = 0;
}	

void main()							    //Main Start
{	
	unsigned char c=0;
  //P1=0x00;	
	TMOD=0X20;
	TH1=-6;
	SCON=0X50;
	TR1=1;
	SBUF=0;							  

while(1)
	{
		c=recieve();
    P1=c;
		transmit(c);
  }	
}

unsigned char recieve()        //   Serial TransmtSubroutine
{
	unsigned char x ;					    //	 Put the data into transmit buffer
	
	while(RI==0);	                //   Wait until transmission of previous occurs
	x=SBUF;
	RI=0;
	return(x);
}  

