#include <REGx51.H>
void delay(unsigned int);
void transmit(unsigned char*);
void main()							    //Main Start
{	
	TMOD=0X20; //00100000
	TH1=0xFD;  ///9600 br
	SCON=0X50;  //01010000
	TR1=1;
	SBUF=0;							  
	
	while(1)
	{
		transmit("Gyan ganga ");			   //for sending the char 
		
	}
}	
 
 void delay (unsigned int del)
{
	unsigned int i,j;	
	for(i=0;i<=del;i++)
		for(j=0;j<=1275;j++);
}
	
void transmit(unsigned char *x)        //   Serial TransmtSubroutine
{
	while(*x)
	{SBUF = *x;					    //	 Put the data into transmit buffer
	while(TI==0);	                //   Wait until transmission of previous occurs
	x++;
	TI = 0;}
	
}	
