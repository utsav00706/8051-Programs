#include <REGx51.H>
void delay(unsigned int);
void transmit(unsigned char);
void main()							    //Main Start
{	
	TMOD=0X20; //00100000
	TH1=0xFD;  ///9600 br
	SCON=0X50;  //01010000
	TR1=1;
	SBUF=0;							  
	
	while(1)
	{
		transmit('G');			   //for sending the char 
		delay(200);
		transmit('y');		
		delay(200);
		transmit('a');
		delay(200);
		transmit('n');
		delay(200);
		transmit(' ');
		delay(200);
		
		
	}
}	
 
 void delay (unsigned int del)
{
	unsigned int i,j;	
	for(i=0;i<=del;i++)
		for(j=0;j<=1275;j++);
}
	
void transmit(unsigned char x)        //   Serial TransmtSubroutine
{
	SBUF = x;					    //	 Put the data into transmit buffer
	while(TI==0);	                //   Wait until transmission of previous occurs
	TI = 0;
}	
