#include <REGX51.H>
void delay(void);
sfr op=0x90;

void main()
{  unsigned char i;
  while(1)
	{	
	op = 0x00;
	for (i=0;i<70;i++)
	{delay();}
	op = 0xFF;
	for (i=0;i<70;i++)
	{delay();}
  }
}

void delay()
{
TMOD = 0x10;   //timer 00010000  timer 1, mode 1
TL1 =	0x05;
TH1 = 0x00;
TR1=1;
	while(TF1==0);
	TR1=0;
	TF1=0;
}
//[(65536-5)]*1.085*70/10^6  =  4.97sec
//{[FFFF-{th1,tl1}]+1]*1.085 us}*70 ==  ((65536-0005)*1.085 us)*70 = 70*(71101.135) = 70*(0.071101135 sec)= 70*0.071101135 = 4.97 sec  

