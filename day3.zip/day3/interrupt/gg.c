#include <REGX51.H>
void delay(unsigned char);
unsigned char a=0,b=0; 
  
void extint0(void) interrupt 0
 { //a=P1;
   P2=P1+5;
	//delay(5000);
 }

 void extint1(void) interrupt 1
 {
	 //b=P1;
   P2=P1+10;
	//delay(5000);
 }


void delay(unsigned char tim)
{
 unsigned int i,j;
 for (i=0;i<=tim;i++)
   for (j-0;j<=1275;j++)
	{}
}

void main()
{ 
	IE = 0x85;
	P1=0xFF;
	P3_2=1;
	P3_3=1;
	while(1)
	{
		P2=P1;
  }
}
