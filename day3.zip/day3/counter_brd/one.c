//toggel after 16 events
#include <REGX51.H>
unsigned char disp(unsigned char );
int i,j;
void main()
{
	unsigned char a=0x55;
	P3=0xFF;
	P1=0x00;	
	TMOD=0x05;    ///00000101  counter zero mode 1 
	TH0=0x00;     //
	TL0=0x00;     //
	TR0=1;
		   do
		    {
			  P2=disp(TL0);
				a=~a;				
				P1=a;
			  }
		    while(TL0<0x0a);
			TR0=0;
	 	
	}

unsigned char disp(unsigned char x)
{
	unsigned char b=0;
	
	  switch(x)
     {	
			 case 0:
			   {
			   b=0x3f;  //00111111
					 break;
         }
        case 1:
			   {
			   b=0x06;   //00000110
					 break;
         }
				case 2:
			   { 
			   b=0x5b;  //01011011
					 break;
         }
				case 3:
			   {
			   b=0x4f;    //01001111
					 break;
         }
				case 4:   
			   {
			   b=0x66;    //01100110
					 break;
         }
				case 5:
			   {
			   b=0x6d;    //01101101
					 break;
         }
				case 6:
			   {
			   b=0x7d;    //01111101
					 break;
         }
				case 7:
			   {
			   b=0x07;      //00000111
					 break;
         }
				case 8:
			   {
			   b=0x7f;     //01111111
					 break;
         }
				case 9:
			   {
			   b=0x6f;   //01101111 
					 break; 
         }
				case 10:
			   {
			   b=0x77;    //01110111
					 break;
         }
				case 11:
			   {
			   b=0x7c;   //01111100
					 break;
         }
				case 12:
			   {
			   b=0x39;     //00111001
					 break;
         }
				case 13:
			   {
			   b=0x5e;      //01011110
					 break;
         }
				case 14:
			   {
			   b=0x79;      // 01111001
					 break;
         }
				default:
			   {
			   b=0x71;       //01110001
					 break;
         }	
				 }
			 return b;
}
