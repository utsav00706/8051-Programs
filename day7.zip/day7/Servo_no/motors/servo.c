#include<reg52.h>
#include<stdio.h>
#include <intrins.h>
sbit motor_pin = P0^0;
void Delay(unsigned int);
void Delay_servo(unsigned int);
void main()
{
  motor_pin = 0;
  do
  {
    //Turn to 0 degree
    motor_pin = 1;
    Delay_servo(75);
    motor_pin = 0;

    Delay(1000);

    //Turn to 90 degree
//    motor_pin=1;
//    Delay_servo(82);
//    motor_pin=0;
//    Delay(1000);

    //Turn to 180 degree
    motor_pin=1;
    Delay_servo(152);
    motor_pin=0;

    Delay(1000);
  }while(1);
}

void Delay(unsigned int ms)
{
  unsigned long int us = ms*1000;
  while(us--)
  {
    _nop_();
  }
}

void Delay_servo(unsigned int us)
{
  while(us--)
  {
    _nop_();
  }
}


////////////75 is minimum for delay for -90 degree
/////152 is maximum delay for +90 degree
////hence (152-75)/180=2.33 degree change for one value change























//#include <REGX51.H>
//void delay(unsigned int);
//sbit motor_pin=P0^0;

//void main()
//{  
//	while(1)
//	{	
//	  motor_pin = 1;
//    delay(10);
//    motor_pin = 0;
//    delay(100);
//    //Turn to 90 degree
//    motor_pin=1;
//    delay(20);
//    motor_pin=0;
//    delay(100);
//    //Turn to 180 degree
//    motor_pin=1;
//    delay(40);
//    motor_pin=0;
//    delay(100);
//	}
//}

//void delay(unsigned int k)
//{
//unsigned int i;
//for(i=1;i<=k;i++)
//{
//TMOD = 0x10;   //timer 00010000  timer 1, mode 1
//TL1 =	0xA3;
//TH1 = 0xFF;
//TR1=1;
//while(TF1==0);
//TR1=0;
//TF1=0;
//}
//}

//[(65535-5)+1]*1.085*70/10^6  =  4.97sec
//{[FFFF-{th1,tl1}]+1]*1.085 us}*70 ==  ((65536-0005)*1.085 us)*70 = 70*(71101.135) = 70*(0.071101135 sec)= 70*0.071101135 = 4.97 sec  

//void delay(unsigned int k) //delay in 100 micro seconds for 11.0592MHz crystal
//{                                            //E.g. delay_ms(100)
//unsigned int i,j;
//for(i=0;i<k;i++)
//{
//for(j=0;j<11;j++); 
//}
//}
