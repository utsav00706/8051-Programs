#include<reg52.h>
#include<stdio.h>
#include <intrins.h>

sbit motor_pin1 = P0^0;
sbit motor_pin2 = P0^1;

void Delay(unsigned int);
void Delay_servo(unsigned int);
void main()
{
  motor_pin1 = 0;
  motor_pin2 = 0;

  do
  {
    //Turn to 0 degree
    motor_pin1 = 1;
    motor_pin2 = 1;
	  Delay_servo(75);
  	motor_pin1 = 0;
    motor_pin2 = 0;   
    Delay(1000);

  //Turn to  degree
   motor_pin1=1;
   Delay_servo(160);
	 motor_pin1=0;
    Delay(1000);
  
		//Turn to  degree
    motor_pin2=1;
    Delay_servo(90);
    motor_pin2=0;
   Delay(1000);		
	}
while(1);
}

void Delay(unsigned int ms)
{
  unsigned long int us = ms*1000;
  while(us--)
  {
    _nop_();
  }
}

void Delay_servo(unsigned int us)
{
  while(us--)
  {
    _nop_();
  }
}