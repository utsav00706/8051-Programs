#include <REGX51.H>
sbit sw1=P2^0;
sbit sw2=P2^1;
sbit sw3=P2^2;
sbit sw4=P2^3;

void main()
{
	unsigned char a,b,c,d;
sw1=1;
sw2=1;
sw3=1;
sw4=1;
	
while(1)
{
	a=sw1;
  b=sw2;
  c=sw3;
  d=sw4;

if  (a==0 && b==1 && c==1 && d==1)
{P0=0x01;
 P1=0X00;}
else if(a==0 && b==0 && c==1 && d==1)
{P0=0x02;
 P1=0X00;}

else if(a==1 && b==0 && c==1 && d==1)
{P0=0x04;
 P1=0X00;}
else if(a==1 && b==0 && c==0 && d==1)
{P0=0x08;
 P1=0X00;}
		
else if(a==1 && b==1 && c==0 && d==1)
{   P0=0x10;
    P1=0X00;}
else if(a==1 && b==1 && c==0 && d==0)
{  P0=0x20;
    P1=0X00;}

else if(a==1 && b==1 && c==1 && d==0)
{ P0=0x40;
    P1=0X00;}
else if(a==0 && b==1 && c==1 && d==0)
{P0=0x80;
    P1=0X00;}

else if(a==0 && b==1 && c==0 && d==1)
{P1=0X01;
 P0=0X00;}
else if(a==1 && b==0 && c==1 && d==0)
{ P1=0x02;
  P0=0X00;}
		
else
{P0=0x00;
P1=0X00;}
	
}
}
	




