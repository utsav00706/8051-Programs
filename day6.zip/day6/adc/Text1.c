#include <REG51.H>
sfr adc_data  =   0x90;				 //ADC Data Port : PORT 1
sbit adc_rd   =   P2^2;				 //ADC read 
sbit adc_rw   =   P2^1;				 //ADC write
sbit adc_int  =   P2^0;				 //ADC Busy Check
sfr ldata  =   0x80;				 //		LCD Data Port : PORT 0
sbit rs    =   P2^5;				 //		LCD Register Select 
sbit rw    =   P2^6;				 //		LCD R/W
sbit en    =   P2^7;				 //		LCD E/N

void initial_disp1(void);			   //Display1 for college name
void initial_disp2(void);			   //Display2 for Project name
void display(unsigned char);		   //Display ADC data to LCD
unsigned char adc_read();
void delay (unsigned int);
void lcdcmd(unsigned int);
void lcddata(unsigned int);
void sendstring(char*);
void lcdinit(void);
void transmit(unsigned char);
unsigned char adc_read(void);
unsigned char temp=0;				   //global variable
unsigned char value = 0;		 //global variable
void main()							    //Main Start
{	
	TMOD=0X20;
	TH1=0XFD;   //9600
	SCON=0X50;  //serial comm mode 2
	TR1=1;
	SBUF=0;							  
	lcdinit();						     //Lcd initialize
	initial_disp1();
	delay(500);
	initial_disp2();
	delay(500);
	lcdcmd(0x01);
	
	while(1)
	{
	  temp =adc_read();
		delay(75);
		lcdcmd(0x80);
		sendstring("  Temp:");	
		display(temp); 	  
		lcddata(0xdf);
		lcddata('C');
		lcddata(' ');
		delay(75);	  
	}
}

void initial_disp1()
{
	lcdinit();
	lcdcmd(0x80);
	sendstring("GGITS eng clg");
	lcdcmd(0x0C);
	lcdcmd(0xC0);
	sendstring("utsav malviya");
	lcdcmd(0xC0);
	delay(1); 				
}
	
void initial_disp2()
{
	lcdinit();
	lcdcmd(0x80);
	sendstring("  Temperature   ");
	lcdcmd(0x0C);
	lcdcmd(0xC0);
	sendstring("Transmitter Unit");
	lcdcmd(0x0C0);
	delay(150);  		
}
void display(unsigned char temp)
{

	unsigned char a=0,b=0,c=0,d=0;
		
		a = (temp/10); 			// for binary to ASCII conversion
		b = (temp%10);
		c = (a/10);
		d = (a%10);
		
		b = b+0x30;
		c = c+0x30;
		d = d+0x30;		
		
		lcddata(c);
		transmit(c);			   //for sending the char 
		lcddata(d);
		transmit(d);		
		lcddata(b);	
		transmit(b);
		return;

}	
 
 void delay (unsigned int del)
{
	unsigned int i,j;
		
	for(i=0;i<=del;i++)
		for(j=0;j<=500;j++);
}
	


void lcdcmd(unsigned int value)
{
	ldata=value;
	rs=0;
	rw=0;
	en=1;	 delay(2);
	en=0;
	return;
}
	 
void lcddata(unsigned int value)
{
	ldata=value;
	rs=1;
	rw=0;
	en=1;	 delay(2);
	en=0;		   
	return;
}
 
void sendstring(char *s)
{
	while(*s)
	{
		lcddata(*s);
		s++;
	}
} 
void lcdinit()
{
	lcdcmd(0x01);
	lcdcmd(0x38);
	lcdcmd(0x0E);
	lcdcmd(0x06);
}


void transmit(unsigned char x)        //   Serial TransmtSubroutine
{
	SBUF = x;					    //	 Put the data into transmit buffer
	while(TI==0);	                //   Wait until transmission of previous occurs
	TI = 0;
}	

unsigned char adc_read()
{
	adc_rw = 0;
	adc_rw = 1;     //soc
	while(adc_int == 1);  //wait for conversion
	adc_rd = 0;        //read
	value = adc_data;		
	adc_rd = 1;	         
	return(value);
}


   
