#include <REGX52.H>
void delay(int);
int i,j,k,l;
sfr lcdport=0xA0;   //port 2
int x,y;
sfr sws=0x80;      //port 0
sfr leds=0x90;     //port 1


sbit buzz=P3^7;
sbit rs=P3^2;
sbit rw=P3^1;
sbit en=P3^0;
sbit count_sw=P3^5;

int a[8];
unsigned char des_by[]="utsav GGITS";
unsigned char start[]="start voating";
unsigned char done[]="DONE";
unsigned char party[]="Party";
void lcddata(unsigned char ldata);
void lcdcmd(unsigned char lcmd);
void main()
{
	P3=0;
	leds=0;
	count_sw=1;
	sws=255;
	//buzz=0;
//	P1=0;


	lcdcmd(0x01);
	lcdcmd(0x38);
	lcdcmd(0x0E);
	lcdcmd(0x80);
		
	for(k=0;k<=10;k++)
		lcddata(des_by[k]) ;
	delay(1000);
	lcdcmd(0x01);
	
	for(k=0;k<=12;k++)
		lcddata(start[k]) ;
	 delay(500);
	lcdcmd(0x01);
	 
	while(1)
	{
	
		switch(sws)
		{
			case 254:  //11111110
			leds=1;    //00000001
			buzz=1;
			lcdcmd(0x86);
			for(k=0;k<=3;k++)
			lcddata(done[k]);
			delay(2000);
			lcdcmd(0x01);
			buzz=0;
			leds=0;
			a[0]++;
			break;

			case 253://11111101
			leds=2;
			buzz=1;
			lcdcmd(0x86);
			for(k=0;k<=3;k++)
			lcddata(done[k]);
			delay(2000);
			lcdcmd(0x01);
			buzz=0;
			leds=0;
			a[1]++ ;
			break;

			case 251://11111011
			leds=4;  //00000100
			buzz=1;
			lcdcmd(0x86);
			for(k=0;k<=3;k++)
			lcddata(done[k]);
			delay(2000);
			lcdcmd(0x01);
			buzz=0;
			leds=0;
			a[2]++;
			break;

			case 247:
			leds=8;
			buzz=1;
			lcdcmd(0x86);
			for(k=0;k<=3;k++)
			lcddata(done[k]);
			delay(2000);
			lcdcmd(0x01);
			buzz=0;
			leds=0;
			a[3]++;
			break;

			case 239:
			leds=16;
			buzz=1;
			lcdcmd(0x86);
			for(k=0;k<=3;k++)
			lcddata(done[k]);
			delay(2000);
			lcdcmd(0x01);
			buzz=0;
			leds=0;
			a[4]++;
			break;

			case 223:
			leds=32;
			buzz=1;
			lcdcmd(0x86);
			for(k=0;k<=3;k++)
			lcddata(done[k]);
			delay(2000);
			lcdcmd(0x01);
			buzz=0;
			leds=0;
			a[5]++;
			break;

			case 191:
			leds=64;
			buzz=1;
			lcdcmd(0x86);
			for(k=0;k<=3;k++)
			lcddata(done[k]);
			delay(2000);
			lcdcmd(0x01);
			buzz=0;
			leds=0;
			a[6]++;
			break;

			case 127:
			leds=128;
			buzz=1;
			lcdcmd(0x86);
			for(k=0;k<=3;k++)
			lcddata(done[k]);
			delay(2000);
			lcdcmd(0x01);
			buzz=0;
			leds=0;
			a[7]++;
			break;
		 
		}
		if(count_sw==0)
			{
				while(1)
				{
					lcdcmd(0x80);
				
					for(k=0;k<=7;k++)
					{
						for(l=0;l<=4;l++)
							lcddata(party[l]);
						lcddata(k+0x31);
						lcddata('=');
						y=a[k]%10;
						x=a[k]/10;
						lcddata(x+0x30);		
						lcddata(y+0x30);
						delay(1000);	
						lcdcmd(0x01);	
					}
					delay(500);						
				  }
			}
	}
}

void delay(int del)
{
	for(i=0;i<=125;i++)
		for(j=0;j<=del;j++);
}

void lcddata(unsigned char ldata)
{
	lcdport=ldata;
	rs=1;
	rw=0;
	en=1;
	delay(1);
	en=0;
}
void lcdcmd(unsigned char lcmd)
{
	lcdport=lcmd;
	rs=0;
	rw=0;
	en=1;
	delay(1);
	en=0;
}