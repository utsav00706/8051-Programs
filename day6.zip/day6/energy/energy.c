#include <REGX51.H>
void delay(unsigned int);
int i,j;
sfr lcdport=0xA0;
sbit enter1=P3^3;
sbit exit1=P3^4;
sbit rs=P3^0;
sbit rw=P3^1;
sbit en=P3^2;
void lcddata(unsigned char ldata);
void lcdcmd(unsigned char lcmd);
unsigned char display_Coll[]="Welcome GGITS";
unsigned char display_project[]="*Energy Saving";
unsigned char des_by[]="Designed by";
unsigned char stu_name[]="utsav malviya";
//unsigned char person[]="no. of person=>";
unsigned int k;
unsigned char a=0,s;
void main()
{
	enter1=1;
	exit1=1;
	P1=0x00;
	lcdcmd(0x01);
	lcdcmd(0x38);
	lcdcmd(0x0E);
	lcdcmd(0x80);
	
	for(k=0;k<=14;k++)
		lcddata(display_Coll[k]) ;

	lcdcmd(0xC0);
	for(k=0;k<=14;k++)
		lcddata(display_project[k]);

	 delay(500);
	lcdcmd(0x01);
	lcdcmd(0x80);
	for(k=0;k<=10;k++)
		lcddata(des_by[k]) ;

	lcdcmd(0xC0);
	for(k=0;k<=12;k++)
		lcddata(stu_name[k]);
delay(500);
lcdcmd(0x01);
lcdcmd(0x80);	
delay(500);
	
  while(1)
	{
	  if(enter1==0 )//&& a<3)
		{	a++;
		delay(300);}
	  else if(exit1==0 && a>0)
		{a--;
		delay(300);}
	  else
			{a=a;}
		
	 if(a==0)
		 { 
		  P1=0x00;}  			
	 else if(a>=1 && a<=3)
		{ P1=0xC3;}
     else if(a>3 && a<=6)
        { P1=0xCf;}
     else 
        { P1=0xff;}	 		
	
//	for(k=0;k<=15;k++)
//		{lcddata(person[k])};
		s=a+0x30;
		lcddata(s);
		//delay(500);
		lcdcmd(0x01);
    }
}

void delay(unsigned int del)
{
	for(i=0;i<=125;i++)
		for(j=0;j<=del;j++);
}
void lcddata(unsigned char ldata)
{
	lcdport=ldata;
	rs=1;
	rw=0;
	en=1;
	delay(1);
	en=0;
}
void lcdcmd(unsigned char lcmd)
{
	lcdport=lcmd;
	rs=0;
	rw=0;
	en=1;
	delay(1);
	en=0;
}