#include <REGX51.H>
sfr row =0xB0;
sfr col1 =0x80;
void delay(unsigned int);
void main()
{
	unsigned int i,j,u;
	unsigned char dat[5]={0x01,0xf6,0xf6,0xf6,0x01};
	unsigned int cc,p1,p=1; 
while(1)
	{
p1=1;
p=1;
for(u=0;u<4;u++)
{		
  p=p1;
	p1=2*p1;
for(i=1;i<100;i++)
	{
		cc=p;
	for(j=0;j<=4-u;j++)
		{
		col1=cc;
		row=dat[j];
		delay(1);
		cc=cc<<1;	
		}
	}
}
}
}
 void delay(unsigned int x)
 { unsigned int i1,j;
     for (i1=0;i1<x;i1++)
         for(j=0;j<125;j++)
 	  {}
 }	
		