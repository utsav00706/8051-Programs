
#include <REGX51.H>
sfr row = 0xB0;
sfr col1 =0x80;
sfr col2 =0x90;
sfr col3 =0xA0;

void delay(unsigned int);
void main()
{
	unsigned int u,i;
  unsigned int k,j;
  
unsigned char dat1[5]={0x00,0x00,0x00,0x00,0x00};
unsigned char dat2[5]={0xff,0xff,0xff,0xff,0xff};
unsigned char dat3[5]={0x00,0x00,0x00,0x00,0x00};
	
unsigned char cc1,cc2,cc3; 
		
while(1)
{
//for(k=0;k<=19;k++)		
//{	
for(i=1;i<20;i++)
{
  cc1=1;
	cc2=1;
	cc3=1;
	//j=k;
	for(u=0;u<=19;u++)	
	{
		col1=cc1;
		col1=cc2;
		col1=cc3;
		
		//col2=cc>>8;
		//col3=cc>>16;
		row=dat[u];
		delay(1);
		cc1=cc1<<1;
    cc2=cc2<<1;
    cc3=cc3<<1;
    
		//j++;
    //if(j>19)
     //j=0;				
	}
}
}
}
}

void delay(unsigned int x)
 { unsigned int i1,j;
     for (i1=0;i1<x;i1++)
         for(j=0;j<50;j++)
 	  {}
 }	
		