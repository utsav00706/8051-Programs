#include <REGX51.H>
sfr row =0xB0;
sfr col1 =0x80;
void delay(unsigned int);
void main()
{
	unsigned int u,i,k;
	unsigned char dat[5]={0x00,0xf7,0xf7,0xf7,0x00};
	//unsigned char dat[5]={0xdd,0xbe,0xbe,0xbe,0xdd};
	
	unsigned char cc;//,p=1; 

while(1)
{
	for(k=0;k<4;k++)
	{cc=1;
for(i=1;i<100;i++)
{
  
	for(u=k;u<=4;u++)	
	{
		col1=cc;
		row=dat[u];
		delay(1);
		cc=cc<<1;				
	}
	
}
//p=p*2;
}
}
}
void delay(unsigned int x)
 { unsigned int i1,j;
     for (i1=0;i1<x;i1++)
         for(j=0;j<125;j++)
 	  {}
 }	
		