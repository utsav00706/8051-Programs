#include <REGX51.H>
sfr row =0xB0;
sfr col1 =0x80;
void delay(unsigned int);
void main()
{
	unsigned int j,u,i,k;
	unsigned char dat[5]={0x00,0xf7,0xf7,0xf7,0x00};
	unsigned int cc; 

while(1)
{
for(k=0;k<=4;k++)		
{	
for(i=1;i<100;i++)
{
  cc=1;
	j=k;
	for(u=0;u<=4;u++)	
	{
		col1=cc;
		row=dat[j];
		delay(1);
		cc=cc<<1;
    j++;
    if(j>4)
      j=0;				
	}
}
}
}
}

void delay(unsigned int x)
 { unsigned int i1,j;
     for (i1=0;i1<x;i1++)
         for(j=0;j<125;j++)
 	  {}
 }	
		