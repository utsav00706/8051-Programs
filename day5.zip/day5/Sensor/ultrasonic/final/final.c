#include<REGX51.h>
#include<intrins.h>  // for using _nop_() function

void lcdcmd(unsigned int);
void lcddata(unsigned int);
void sendstring(char*);
void lcdinit(void);
void initial_disp1(void);			   //Display1 for college name

sfr ldata  =   0xA0;				 //		LCD Data Port : PORT 1
sbit rs    =   P1^5;				 //		LCD Register Select 
sbit rw    =   P1^6;				 //		LCD R/W
sbit en    =   P1^7;				 //		LCD E/N

sfr16 DPTR =0x82;// you can use DPTR as a single 16 bit register
sbit trig=P3^5;
void send_pulse(void) //to generate 10 microseconds delay
{
TH0=0x00;TL0=0x00; 
 trig=1;
 _nop_();_nop_();_nop_();_nop_();_nop_();
 _nop_();_nop_();_nop_();_nop_();_nop_();
 trig=0;
} 

unsigned char get_range(void) 
{
 unsigned char range;
 send_pulse();
    while(!INT0);//         in sake of these lines you can generate a delay of 40 Milli seconds=40000 micro 
    while (INT0);//         seconds
 DPH=TH0;DPL=TL0; 
 TH0=0xFF;TL0=0xFF;
 if(DPTR<35000)//actually you need to use 38000 but the sensor may not work at higher levels 
  range=DPTR/59;
  else
  range=0; // indicates that there is no obstacle in front of the sensor 
  return range; 
}

void display(unsigned int temp)
{

	unsigned char a=0,b=0,c=0,d=0;
		
		a = (temp/10); 			// for binary to ASCII conversion
		b = (temp%10);
		c = (a/10);
		d = (a%10);
		
		b = b+0x30;
		c = c+0x30;
		d = d+0x30;		
		
		lcddata(c);
		lcddata(d);
		lcddata(b);	
		return;

}	

 void delay (unsigned int del)
{
	unsigned int i,j;
		
	for(i=0;i<=del;i++)
		for(j=0;j<=500;j++);
}

void main()
{
	
  unsigned int target_range=0;
	//main begin
  TMOD=0x09;//timer0 in 16 bit mode with gate enable
  TR0=1;//timer0 run enabled
  TH0=0x00;TL0=0x00;
  P3|=0x04;//setting pin P3.2 to make it INPUT
  initial_disp1();

 while(1)
 {    
   target_range=get_range();
   P0=target_range;	 
	 delay(75);
		lcdcmd(0x80);
		sendstring(" Range: ");	
		display(target_range); 	  
		lcddata(' ');
	 lcddata('C');
		lcddata('M');
		delay(75);
	     
        //make your own function to display the range value.better to use LCD
 }
}// end of main

void sendstring(char *s)
{
	while(*s)
	{
		lcddata(*s);
		s++;
	}
} 
void lcdinit()
{
	lcdcmd(0x01);
	lcdcmd(0x38);
	lcdcmd(0x0E);
	lcdcmd(0x06);
}

void lcdcmd(unsigned int value)
{
	ldata=value;
	rs=0;
	rw=0;
	en=1;	 delay(2);
	en=0;
	return;
}
	 
void lcddata(unsigned int value)
{
	ldata=value;
	rs=1;
	rw=0;
	en=1;	 delay(2);
	en=0;		   
	return;
}
void initial_disp1()
{
	lcdinit();
	lcdcmd(0x80);
	sendstring("GGITS eng clg");
//	lcdcmd(0x0C);
	lcdcmd(0xC0);
	sendstring("utsav malviya");
	//lcdcmd(0xC0);
	delay(100);
lcdcmd(0x01);
		
}
