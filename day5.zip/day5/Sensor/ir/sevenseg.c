#include <REGX51.h>
sbit a=P3^0;
void main(void)
{
P0=0x00;
	a=1;
while(1)
{ 
  if(a==0)
		P0=0x01;
	else
	  P0=0x00;
}
}
