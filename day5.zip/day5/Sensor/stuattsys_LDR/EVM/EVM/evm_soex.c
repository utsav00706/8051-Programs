#include <REGX52.H>
void delay(int);
int i,j,k,l;
sfr lcdport=0xA0;
int x,y;




sbit rs=P1^0;
sbit rw=P1^1;
sbit en=P1^2;


int a[8];
unsigned char display_Coll[]="Welcome to SOEX";
unsigned char display_project[]="***EVM***";
unsigned char party[]="Party";
unsigned char start_vote[]="Start Voting";

void lcddata(unsigned char ldata);
void lcdcmd(unsigned char lcmd);
void main()
{
	P3=0;
//	buzz=0;
//	leds=0;
//	count_sw=1;
//	sws=0;
	lcdcmd(0x01);
	lcdcmd(0x38);
	lcdcmd(0x0E);
	lcdcmd(0x40);
		
	for(k=0;k<=14;k++)
		lcddata(display_Coll[k]) ;

	lcdcmd(0x10);
	for(k=0;k<=8;k++)
		lcddata(display_project[k]);

	 delay(500);
   /*
	while(1)
	{
	
		switch(sws)
		{
			case 1:
			leds=1;
			buzz=1;
			delay(1000);
			buzz=0;
			leds=0;
			a[0]++;
			break;

			case 2:
			leds=2;
			buzz=1;
			delay(1000);
			buzz=0;
			leds=0;
			a[1]++ ;
			break;

			case 4:
			leds=4;
			buzz=1;
			delay(1000);
			buzz=0;
			leds=0;
			a[2]++;
			break;

			case 8:
			leds=8;
			buzz=1;
			delay(1000);
			buzz=0;
			leds=0;
			a[3]++;
			break;

			case 16:
			leds=16;
			buzz=1;
			delay(1000);
			buzz=0;
			leds=0;
			a[4]++;
			break;

			case 32:
			leds=32;
			buzz=1;
			delay(1000);
			buzz=0;
			leds=0;
			a[5]++;
			break;

			case 64:
//			leds=64;
//			buzz=1;
			delay(1000);
//			buzz=0;
//			leds=0;
			a[6]++;
			break;

			case 128:
//			leds=128;
//			buzz=1;
			delay(1000);
//			buzz=0;
//			leds=0;
			a[7]++;
			break;
		 
		}
//		if(count_sw==0)
			{
				while(1)
				{
					lcdcmd(0x01);
					lcdcmd(0x38);
					lcdcmd(0x80);
				
					for(k=0;k<=7;k++)
					{
						for(l=0;l<=4;l++)
							lcddata(party[l]);
						lcddata(k+0x31);
						lcddata('=');
						y=a[k]%10;
						x=a[k]/10;
						lcddata(x+0x30);		
						lcddata(y+0x30);		
						lcddata(',');
						if(k==3)
							lcdcmd(0xC0);
					}
					delay(500);
					for(l=0;l<=22;l++)
					{
						lcdcmd(0x18);
						delay(500);
					}
					delay(500);						
				  }
			}
				   
	
	}	*/
}

void delay(int del)
{
	for(i=0;i<=125;i++)
		for(j=0;j<=del;j++);
}

void lcddata(unsigned char ldata)
{
	lcdport=ldata;
	rs=1;
	rw=0;
	en=1;
	delay(1);
	en=0;
}
void lcdcmd(unsigned char lcmd)
{
	lcdport=lcmd;
	rs=0;
	rw=0;
	en=1;
	delay(1);
	en=0;
}