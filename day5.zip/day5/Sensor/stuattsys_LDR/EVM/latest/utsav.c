#include <REGX51.H>
void delay(int);
int i,j,k,l;
sfr lcdport=0xA0;
int x,y;
sfr sws=0x80;
sfr leds=0x90;


sbit buzz=P3^7;
sbit rs=P3^0;
sbit rw=P3^1;
sbit en=P3^2;
sbit count_sw=P3^5;

int a[8];
unsigned char display_Coll[]="Welcome to CIIT";
unsigned char display_project[]="****EVM****";
unsigned char des_by[]="Designed by";
unsigned char stu_name[]="Prashant, Sachin";
unsigned char guid_by[]="Guided by:";
unsigned char guide[]="Mr. Saurav sir";
unsigned char party[]="Party";
void lcddata(unsigned char ldata);
void lcdcmd(unsigned char lcmd);
void main()
{
	P3=0;
	leds=0;
	count_sw=1;
	sws=255;
	buzz=1;
	P1=0;


	lcdcmd(0x01);
	lcdcmd(0x38);
	lcdcmd(0x0E);
	lcdcmd(0x80);
		
	for(k=0;k<=14;k++)
		lcddata(display_Coll[k]) ;

	lcdcmd(0xC3);
	for(k=0;k<=10;k++)
		lcddata(display_project[k]);

	 delay(500);
	lcdcmd(0x01);
	lcdcmd(0x38);
	lcdcmd(0x0E);
	lcdcmd(0x80);


	for(k=0;k<=10;k++)
		lcddata(des_by[k]) ;

	lcdcmd(0xC0);
	
	for(k=0;k<=15;k++)
	{
		lcddata(stu_name[k]);
	}

   delay(500);
//	for(l=0;l<=30;l++)
//	{
//	 lcdcmd(0x18);
//	 delay(100);
//	}			  
   
	while(1)
	{
	
		switch(sws)
		{
			case 254:
			leds=1;
			buzz=0;
			delay(1000);
			buzz=1;
			leds=0;
			a[0]++;
			break;

			case 253:
			leds=2;
			buzz=0;
			delay(1000);
			buzz=1;
			leds=0;
			a[1]++ ;
			break;

			case 251:
			leds=4;
			buzz=0;
			delay(1000);
			buzz=1;
			leds=0;
			a[2]++;
			break;

			case 247:
			leds=8;
			buzz=0;
			delay(1000);
			buzz=1;
			leds=0;
			a[3]++;
			break;

			case 239:
			leds=16;
			buzz=0;
			delay(1000);
			buzz=1;
			leds=0;
			a[4]++;
			break;

			case 223:
			leds=32;
			buzz=0;
			delay(1000);
			buzz=1;
			leds=0;
			a[5]++;
			break;

			case 191:
			leds=64;
			buzz=0;
			delay(1000);
			buzz=1;
			leds=0;
			a[6]++;
			break;

			case 127:
			leds=128;
			buzz=0;
			delay(1000);
			buzz=1;
			leds=0;
			a[7]++;
			break;
		 
		}
		if(count_sw==0)
			{
				while(1)
				{
					lcdcmd(0x01);
					lcdcmd(0x38);
					lcdcmd(0x80);
				
					for(k=0;k<=7;k++)
					{
						for(l=0;l<=4;l++)
							lcddata(party[l]);
						lcddata(k+0x31);
						lcddata('=');
						y=a[k]%10;
						x=a[k]/10;
						lcddata(x+0x30);		
						lcddata(y+0x30);
						delay(500);	
						lcdcmd(0x01);	
						//lcddata(',');
						//if(k==3)
							//lcdcmd(0xC0);
					}
				//	delay(500);
				//	for(l=0;l<=22;l++)
				//	{
				//		lcdcmd(0x18);
				//		delay(500);
				//	}
					delay(500);						
				  }
			}
				   
	
	}
}

void delay(int del)
{
	for(i=0;i<=125;i++)
		for(j=0;j<=del;j++);
}

void lcddata(unsigned char ldata)
{
	lcdport=ldata;
	rs=1;
	rw=0;
	en=1;
	delay(1);
	en=0;
}
void lcdcmd(unsigned char lcmd)
{
	lcdport=lcmd;
	rs=0;
	rw=0;
	en=1;
	delay(1);
	en=0;
}