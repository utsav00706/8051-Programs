#include <REG51.H>
sfr input  =   0x90;				 
sbit buzz   =   P2^0;				  
void main()							    
{	
	input=0xff;
	while(1)
	{ 
		if(input==0xfc)
	  buzz=1;
   else
    buzz=0;		 
	}
}

