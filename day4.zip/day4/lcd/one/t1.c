#include <REGX51.H>
void delay(unsigned int);
int i,j;
sfr lcdport=0xA0;
sbit rs=P3^0;
sbit rw=P3^1;
sbit en=P3^2;
void lcddata(unsigned char ldata);
void lcdcmd(unsigned char lcmd);
unsigned char display_Coll[]="Welcome GGITS   ";
//unsigned char display_project[]="*Energy Saving";
//unsigned char des_by[]="Designed by";
//unsigned char stu_name[]="utsav malviya";
unsigned int k,u;
unsigned char a,s;
void main()
{
	lcdcmd(0x38);
	lcdcmd(0x0E);  //0D//0F//0C
	lcdcmd(0x06); //04//05//06//07
	lcdcmd(0x01);
	lcdcmd(0x80);

for(k=0;k<=12;k++)
	{
		lcddata(display_Coll[k]);
      delay(20);
	} 
	    delay(2000);
	
}
		

void delay(unsigned int del)
{
	for(i=0;i<=125;i++)
		for(j=0;j<=del;j++);
}
void lcddata(unsigned char ldata)
{
	lcdport=ldata;
	rs=1;
	rw=0;
	en=1;
	delay(1);
	en=0;
}
void lcdcmd(unsigned char lcmd)
{
	lcdport=lcmd;
	rs=0;
	rw=0;
	en=1;
	delay(1);
	en=0;
}