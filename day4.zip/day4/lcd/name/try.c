//Program to display hindi alphabets. This program displays a set of five hindi characters at a time due to the size CG Ram.
// To display any other set of five characters use corresponding values from the array.

#include<reg51.h>
sfr cmdport= 0xB0; 
sfr dataport=0xA0; 
sbit rs = P3^0;  //Register select (RS) pin
sbit rw = P3^1;  //Read write (RW) pin)
sbit en = P3^2;  //Enable (EN) pin

void delay(unsigned int msec)  //Time delay function
{
int i,j ;
for(i=0;i<msec;i++)
  for(j=0;j<1275;j++);
}

void lcd_cmd(unsigned char item)  //Function to send command to LCD
{
dataport = item;
rs= 0; 
rw=0; 
en=1; 
delay(1);
en=0;
}

void lcd_data(unsigned char item)  // Function to send data to LCD
{
dataport = item;
rs= 1; 
rw=0; 
en=1; 
delay(1);
en=0;
}

void lcd_shape(unsigned char *letter,int j)  // Function to create custom shapes
{
int i;
lcd_cmd(j);
for(i=0;i<8;i++)
{
  lcd_data(*letter);
  letter++;
}
}

void main()
{
unsigned char letter[4][8]= {31,17,02,04,02,17,14,0,31,0,0,31,16,8,4,0,31,9,5,9,31,9,5,0,31,2,14,18,14,2,2,0};

unsigned char  j=0,i=0;
char a = 0x80;  // Set cursor to first position of first line
int z;
lcd_cmd(0x38); 
lcd_cmd(0x0e);
delay(50);
lcd_cmd(0x01);  //Clear LCD screen
lcd_cmd(0x06);
delay(50);
  z=64;
  a=0x80; 
  for(i=0;i<4;i++)
  {
	 lcd_shape(&letter[i][0],z);  //address of every row's first element 
		                            //Send different alphabet values to shape func to custom different alphabets
   delay(50);
   lcd_cmd(a);  //Move cusrsor to ath position 
   lcd_data(i);  //Display the alphabet on LCD
   delay(50);
   a=a+1;  
   z=z+8;  // Change the address register where values are to be stored(e.g. 64,72,80.......)
  }
//}  
//}
}