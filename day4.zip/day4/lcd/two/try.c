#include<reg51.h>
//sfr cmdport= 0xB0; 
sfr dataport=0xA0; 
sbit rs = P3^0;  //Register select (RS) pin
sbit rw = P3^1;  //Read write (RW) pin)
sbit en = P3^2;  //Enable (EN) pin

void delay(unsigned int msec)  //Time delay function
{
int i,j ;
for(i=0;i<msec;i++)
  for(j=0;j<1275;j++);
}

void lcd_cmd(unsigned char item)  //Function to send command to LCD
{
dataport = item;
rs= 0; 
rw=0; 
en=1; 
delay(1);
en=0;
}

void lcd_data(unsigned char item)  // Function to send data to LCD
{
dataport = item;
rs= 1; 
rw=0; 
en=1; 
delay(1);
en=0;
}

void main()
{
unsigned char letter[4][8]= {31,17,02,04,02,17,14,0,31,0,0,31,16,8,4,0,31,9,5,9,31,9,5,0,31,2,14,18,14,2,2,0};

unsigned char  j=0,i=0;
char a = 0x8e;  //8e//8e
unsigned char z=0x40;
lcd_cmd(0x38); 
lcd_cmd(0x0e);
lcd_cmd(0x05);  //07//05
for(j=0;j<4;j++)	 
{
	for(i=0;i<8;i++)
    {
		 lcd_cmd(z);
     lcd_data(letter[j][i]);
     z=z+1; 
		}
	   a=a+1;                         
  // delay(1);
   lcd_cmd(a);  //Move cusrsor to ath position 
   lcd_data(j);
	}		
}