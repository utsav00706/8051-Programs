void lcd_init(void);
void delay(unsigned int);
void lcddata(unsigned char);
void lcdcmd(unsigned char);
