#include <REGX51.H>
#include <lcd_gg.c>
unsigned char display_Coll[]="Welcome GGITS";
unsigned char display_project[]="*Energy Saving";
unsigned char des_by[]="Designed by";
unsigned char stu_name[]="utsav malviya";
unsigned int k;
unsigned char a,s;

void main()
{
	P1=0x00;
	P3=0x00;
	P2=0x00;	
	lcd_init();
	for(k=0;k<=12;k++)
		{lcddata(display_Coll[k]);
      delay(100);}			
	lcdcmd(0x07);
  lcdcmd(0xCF);
	for(k=0;k<=14;k++)
		{lcddata(display_project[k]);
    delay(100);}
	delay(500);
		
delay(500);
delay(500);
	}

