#include <REGx51.H>
sfr ldata  =   0xA0;				 //		LCD Data Port : PORT 0
sbit rs    =   P3^0;				 //		LCD Register Select 
sbit rw    =   P3^1;				 //		LCD R/W
sbit en    =   P3^2;				 //		LCD E/N
void display(unsigned int);		   //Display ADC data to LCD
void delay (unsigned int);
void lcdcmd(unsigned int);
void lcddata(unsigned int);
void sendstring(char*);
void lcdinit(void);

void main()							    //Main Start
{	
	lcdinit();						     //Lcd initialize
	sendstring("GGITS eng clg");
	lcdcmd(0xC0);
	sendstring("value => ");
	display(243);
	delay(20000);
}

void display(unsigned int temp)
{

	unsigned char a=0,b=0,c=0,d=0;
		
		a = (temp/10); 			// for binary to ASCII conversion
		b = (temp%10);
		c = (a/10);
		d = (a%10);
		
		b = b+0x30;
		c = c+0x30;
		d = d+0x30;		
		
		lcddata(c);
		lcddata(d);
		lcddata(b);	
		return;

}	
 
 void delay (unsigned int del)
{
	unsigned int i,j;
		
	for(i=0;i<=del;i++)
		for(j=0;j<=500;j++);
}
	


void lcdcmd(unsigned int value)
{
	ldata=value;
	rs=0;
	rw=0;
	en=1;	 delay(2);
	en=0;
	return;
}
	 
void lcddata(unsigned int value)
{
	ldata=value;
	rs=1;
	rw=0;
	en=1;	 delay(2);
	en=0;		   
	return;
}
 
void sendstring(char *s)
{
	while(*s)
	{
		lcddata(*s);
		s++;
	}
} 
void lcdinit()
{
	lcdcmd(0x01);
	lcdcmd(0x38);
	lcdcmd(0x0E);
	lcdcmd(0x06);
}
