#include <REG51.H>
sbit x =P1^0;
sbit rly=P0^0; 
void main()							    //Main Start
{	
	x=1;
	while(1)
	{ 
		if(x==0)
	  rly=1;
   else
    rly=0;		 
	}
}

