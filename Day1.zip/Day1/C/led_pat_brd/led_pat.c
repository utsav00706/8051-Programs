#include<reg51.h>
void delay(unsigned char);
void main()
{
unsigned char b,p,q;
	unsigned int b1;
while(1)
{
	b=1;
	b1=256;
for(p=1;p<=8;p++)
{ 
  b=b*2;
  q=b-1;
  P2=q;
	delay(1000);
}
for(p=1;p<=8;p++)
{ 
  q=b1-1;
	P2=q;
	b1=b1/2;
	delay(1000);
  
}
}
}

void delay(unsigned char x)
{ int i,j;
for(i=1;i<x;i++)
for(j=1;j<1275;j++);
}