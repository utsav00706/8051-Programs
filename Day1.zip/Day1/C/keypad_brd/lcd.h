#ifndef lcd_h
#define lcd_h 1

void lcddelay(int);
void LCDWriteString(int x,int y, unsigned char ldata[]);
void LCDWriteInt(int x,int y, int lnum);
//void LCDWriteNum(int x,int y, float lnum);
void LCDInit();
void LCDClear();
//char * LCDGetData();
#endif