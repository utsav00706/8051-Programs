#include <REGX52.H>
sfr op = 0xA0;
sfr keyport = 0x90;
void main()
{
while(1)
{
keyport=0xFE;
if(keyport==0xEE)
 op = 0;
if(keyport==0xDE)
op = 1;
if(keyport==0xBE)
op = 2;
if(keyport==0x7E)
op = 3;
keyport=0xFD;
if(keyport==0xED)
op = 4;
if(keyport==0xDD)
op = 5;
if(keyport==0xBD)
op = 6;
if(keyport==0x7D)
op = 7;
keyport=0xFB;
if(keyport==0xEB)
op = 8;
if(keyport==0xDB)
op = 9;
if(keyport==0xBB)
op = 10;
if(keyport==0x7B)
op = 11;
keyport=0xF7;
if(keyport==0xE7)
op = 12;
if(keyport==0xD7)
op = 13;
if(keyport==0xB7)
op = 14;
if(keyport==0x77)
op = 15;
}
}

//void delay(int del)
//{
//int i,j;
//for(i=1;i<=del;i++)
  //for(j=1;j<=1275;j++);
//}
