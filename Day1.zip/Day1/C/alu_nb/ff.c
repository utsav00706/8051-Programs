#include <REGX51.H>
void delay(unsigned int);
sfr port0=0x80;
sfr port1=0x90;
sfr port3=0xB0;
sbit s0 = P2^0;
sbit s1 = P2^1;
void main()
{	
	unsigned char i,j;
	unsigned int l;
	unsigned char add,sub,rem,quo,lsbmul,msbmul;
	
	port3=0xff;
	port0=0xff;
	
	s0=1;
  s1=1;
	while(1)
	{
	i=port0;
	j=port3;
	l=i*j;
	quo=i/j;	
	rem=i%j;
	sub=i-j;
	add=i+j;
	lsbmul=l%0x100; //000100000000
  msbmul=l/0x100; 
if(s0==0 && s1==0)
{port1=add;}
else if (s0==1 && s1==0)
{port1=sub;}
else if (s0==1 && s1==1)
{port1=lsbmul;
   delay(200);
port1=msbmul;
delay(200);}
else
{port1=quo;
  delay(200);
port1=rem;
delay(200);}
}
}
void delay(unsigned int x)
{ 
 unsigned int u,m;
	  for(u=0;u<x;u++)
	  {
      for(m=0;m<1275;m++)
	     {
		   }
		}
}
	
  