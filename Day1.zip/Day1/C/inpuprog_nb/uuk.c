//Write an 8051 C program to get a byte of data form P0. If it is less than 100,
//send it to P1; otherwise, send it to P2.
#include <reg51.h>

void main(void)
{
unsigned char mybyte;
  P0=0xff; //make P0 input port
  P3=0x00;
	P1=0x00;
	P2=0x00;
	while (1)
{
mybyte=P0; //get a byte from P0
if (mybyte<100)
{P1=mybyte; //send it to P1
P2=0x00;}
else
{P2=mybyte; //send it to P2
P1=0x00;}
}
}
