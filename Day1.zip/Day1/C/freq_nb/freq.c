//program for gertion 50 hz frqency on p2.3,100 hz on p2.4
#include <REGX51.H>
sbit ck1=P2^0;
sbit ck2=P2^1;
void delay(unsigned int);
void main()
{
 while(1)
   { 
      
	  ck2=1;
	  ck1=1;
	  delay(10);
	  ck1=0;
	  delay(10);
	  ck2=0;
	  ck1=1;
	  delay(10);
	  ck1=0;
	  delay(10);
	  }
	}
void delay(unsigned int x)
{ unsigned int i,j;
     for (i=0;i<x;i++)
	    for(j=0;j<1275;j++)
	    {}
}
		