// program for togle a port0 & port0.1 with dealy of 25 ms
#include <REGX51.H>
sfr pp = 0x90;
void delay_ms(unsigned int);
void main()
{
	while(1)
	//for (i=0;i<50;i++)
	{
		pp=0x55;
		delay_ms(250);
		pp=0xAA;
		delay_ms(250);
	}
}
		
void delay_ms(unsigned int k) 
{                                            
unsigned int i,j;
for(i=0;i<k;i++)
{
for(j=0;j<1275;j++); 
}
}
