#include <REGX51.h>
sbit one=P3^0;
sbit two=P3^1;
sbit three=P3^2;
sbit four=P3^3;
unsigned char disp(unsigned char);
void delay(unsigned int);
void main()
{
unsigned int p=0,q=0;
unsigned int mybyte=0,u=0;
unsigned char d1=0,d2=0,d3=0,d4=0,dd1=0,dd2=0,dd3=0,dd4=0;  

	mybyte=0x0000; 
	
while(1)
{
  mybyte=mybyte+1;	 
  d4=mybyte/0x1000;
  p=mybyte%0x1000;
  q=p%0x100;
  d3=p/0x100;
  d1=q%0x10;
  d2=q/0x10;	
  dd1= disp(d1);
  dd2= disp(d2);
  dd3= disp(d3);
  dd4= disp(d4);
	
for (u=0;u<50;u++)
{
  P2=dd1;
  one=1;
  two=0;
	three=0;
	four=0;
	//delay(2);
  P2=dd2;
  one=0;
  two=1;
	three=0;
	four=0;
	//delay(2);
  P2=dd3;
  one=0;
  two=0;
	three=1;
	four=0;
	//delay(2);
  P2=dd4;
  one=0;
  two=0;
	three=0;
	four=1;
//	delay(2); 
}

}
}

unsigned char disp(unsigned char x)
{
	unsigned char b=0;
	
	  switch(x)
     {	
			 case 0:
			   {
			   b=0x3f;  //00111111
					 break;
         }
        case 1:
			   {
			   b=0x06;   //00000110
					 break;
         }
				case 2:
			   { 
			   b=0x5b;  //01011011
					 break;
         }
				case 3:
			   {
			   b=0x4f;    //01001111
					 break;
         }
				case 4:   
			   {
			   b=0x66;    //01100110
					 break;
         }
				case 5:
			   {
			   b=0x6d;    //01101101
					 break;
         }
				case 6:
			   {
			   b=0x7d;    //01111101
					 break;
         }
				case 7:
			   {
			   b=0x07;      //00000111
					 break;
         }
				case 8:
			   {
			   b=0x7f;     //01111111
					 break;
         }
				case 9:
			   {
			   b=0x6f;   //01101111 
					 break; 
         }
				case 10:
			   {
			   b=0x77;    //01110111
					 break;
         }
				case 11:
			   {
			   b=0x7c;   //01111100
					 break;
         }
				case 12:
			   {
			   b=0x39;     //00111001
					 break;
         }
				case 13:
			   {
			   b=0x5e;      //01011110
					 break;
         }
				case 14:
			   {
			   b=0x79;      // 01111001
					 break;
         }
				default:
			   {
			   b=0x71;       //01110001
					 break;
         }	
				 }
			 return b;
}

void delay(unsigned int i)
{ unsigned int j,k;
	  for(j=0;j<i;j++)
	   for(k=0;k<1275;k++);
}