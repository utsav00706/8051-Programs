#include <REGX51.H>
void delay(unsigned int);

sbit r1=P0^0;
sbit r2=P0^1;
sbit r3=P0^2;

void main()
{


  while(1)
	{ 
		P0=0xff;
		P3=0xfe;
		delay(250);
		P3=0xfc;
		delay(250);
		P3=0xf8;
		delay(250);
		P3=0xe0;
		delay(250);
		P3=0xc0;
		delay(250);
		P3=0x80;
		delay(250);
		P3=0x00;
		delay(250);
}
}

 void delay(unsigned int x)
{ unsigned int i,j;
    for (i=0;i<x;i++)
        for(j=0;j<1275;j++)
	  {}
}	
		
		