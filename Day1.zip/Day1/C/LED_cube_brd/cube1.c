#include <REGX51.H>
void delay(unsigned int);

void main()
{
    
  while(1)
	{ 
		P3=0xFE;
		P0=0x07;
		delay(500);
		P3=0xFD;
		P0=0x07;
		delay(500);
		P3=0xFB;
		P0=0x07;
		delay(500);
		P3=0xF7;
		P0=0x07;
		delay(500);
		P3=0xEF;
		P0=0x07;
		delay(500);
		P3=0xDF;
		P0=0x07;
		delay(500);
		P3=0xBF;
		P0=0x07;
		delay(500);
		P3=0x7F;
		P0=0x07;
		delay(2000);
		
		P3=0x00;
		P0=0x01;
		delay(500);
		P3=0x00;
		P0=0x02;
		delay(500);
		P3=0x00;
		P0=0x04;
		delay(2000);
		
		
}
}

 void delay(unsigned int x)
{ unsigned int i,j;
    for (i=0;i<x;i++)
        for(j=0;j<175;j++)
	  {}
}	
		
		